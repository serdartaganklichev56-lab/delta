/**
 * Delta Token Server — LiveKit Egress endpointlari
 *
 * Bu faylni mavjud token server (server.js yoki app.js) ga qo'shing:
 *   const egressRoutes = require('./server_egress_routes');
 *   app.use(egressRoutes);
 *
 * Kerakli paketlar:
 *   npm install livekit-server-sdk
 *
 * Muhit o'zgaruvchilari (yoki to'g'ridan-to'g'ri qiymat):
 *   LIVEKIT_URL    = ws://178.105.129.234:7880
 *   LIVEKIT_KEY    = devkey
 *   LIVEKIT_SECRET = delta_secret_2024
 *   RECORDINGS_DIR = /var/recordings   (yoki istalgan papka)
 *   TELEGRAM_BOT_TOKEN = <bot_token>   (webhook handler uchun)
 */

const express = require('express');
const router  = express.Router();
const { EgressClient, EncodedFileType } = require('livekit-server-sdk');
const path    = require('path');
const fs      = require('fs');
const https   = require('https');

const LIVEKIT_URL    = process.env.LIVEKIT_URL    || 'ws://178.105.129.234:7880';
const LIVEKIT_KEY    = process.env.LIVEKIT_KEY    || 'devkey';
const LIVEKIT_SECRET = process.env.LIVEKIT_SECRET || 'delta_secret_2024';
const RECORDINGS_DIR = process.env.RECORDINGS_DIR || '/var/recordings';
const BOT_TOKEN      = process.env.TELEGRAM_BOT_TOKEN || '';

// Recordings papkasi yo'q bo'lsa yaratamiz
if (!fs.existsSync(RECORDINGS_DIR)) {
  fs.mkdirSync(RECORDINGS_DIR, { recursive: true });
}

const egressClient = new EgressClient(LIVEKIT_URL, LIVEKIT_KEY, LIVEKIT_SECRET);

// ─────────────────────────────────────────────────────────────────
// POST /egress/start — Dars boshlananda chaqiriladi
// Body: { roomName, metadata, ustozName, chatId }
// ─────────────────────────────────────────────────────────────────
router.post('/egress/start', async (req, res) => {
  try {
    const { roomName, metadata, ustozName, chatId } = req.body;
    if (!roomName) return res.status(400).json({ error: 'roomName kerak' });

    const fileName = `${roomName}_${Date.now()}.mp4`;
    const filePath = path.join(RECORDINGS_DIR, fileName);

    // RoomCompositeEgress — barcha ishtirokchilar yoziladi
    const egressInfo = await egressClient.startRoomCompositeEgress(roomName, {
      file: {
        filepath: filePath,
        fileType: EncodedFileType.MP4,
      },
    }, {
      // Metadata — webhook handler bu ma'lumotni ishlatadi
      metadata: metadata || JSON.stringify({ chat_id: chatId, ustoz: ustozName }),
    });

    console.log(`[EGRESS] Boshlandi: ${egressInfo.egressId} | xona: ${roomName}`);
    res.json({ egressId: egressInfo.egressId, filePath });
  } catch (err) {
    console.error('[EGRESS] Boshlashda xato:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────
// POST /egress/stop — Dars tugaganda chaqiriladi
// Body: { egressId }
// ─────────────────────────────────────────────────────────────────
router.post('/egress/stop', async (req, res) => {
  try {
    const { egressId } = req.body;
    if (!egressId) return res.status(400).json({ error: 'egressId kerak' });

    const egressInfo = await egressClient.stopEgress(egressId);
    console.log(`[EGRESS] To'xtatildi: ${egressId}`);
    res.json({ ok: true, egressId });
  } catch (err) {
    console.error('[EGRESS] To\'xtatishda xato:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────
// POST /egress/webhook — LiveKit Egress tugaganda webhook
//
// LiveKit server sozlamalarida webhook URL ni ko'rsating:
//   egress:
//     webhook_url: http://<server_ip>:3000/egress/webhook
//
// Egress tugatilgandan keyin LiveKit bu endpointni chaqiradi.
// Metadata dan chat_id va ustoz olinib, Telegram ga fayl yuboriladi.
// ─────────────────────────────────────────────────────────────────
router.post('/egress/webhook', express.json({ type: '*/*' }), async (req, res) => {
  try {
    const event = req.body;
    // Faqat egress_ended eventini qayta ishlaymiz
    if (event.event !== 'egress_ended') return res.json({ ok: true });

    const egressInfo = event.egressInfo || {};
    const metadata   = JSON.parse(egressInfo.metadata || '{}');
    const chatId     = metadata.chat_id;
    const ustozNom   = metadata.ustoz || 'Ustoz';

    // Yozilgan fayl manzili
    const fileResult = (egressInfo.file || egressInfo.fileResults?.[0]);
    const filePath   = fileResult?.location || fileResult?.filename;

    console.log(`[WEBHOOK] Egress tugadi: ${egressInfo.egressId} | chat: ${chatId} | fayl: ${filePath}`);

    // Telegram ga yuborish
    if (chatId && filePath && BOT_TOKEN && fs.existsSync(filePath)) {
      await sendToTelegram(chatId, filePath, ustozNom);
    } else {
      console.warn('[WEBHOOK] Telegram yuborilmadi:', { chatId: !!chatId, filePath: !!filePath, bot: !!BOT_TOKEN });
    }

    res.json({ ok: true });
  } catch (err) {
    console.error('[WEBHOOK] Xato:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────
// Yordamchi: Telegram ga video fayl yuborish
// ─────────────────────────────────────────────────────────────────
async function sendToTelegram(chatId, filePath, ustozNom) {
  if (!BOT_TOKEN) {
    console.warn('[TELEGRAM] BOT_TOKEN yo\'q — yuborib bo\'lmadi');
    return;
  }
  try {
    const FormData = require('form-data');
    const axios    = require('axios'); // yoki native https ishlatishingiz mumkin

    const form = new FormData();
    form.append('chat_id', chatId);
    form.append('caption', `🎓 Dars yozuvi\n👨‍🏫 Ustoz: ${ustozNom}\n📅 ${new Date().toLocaleString('uz')}`);
    form.append('video', fs.createReadStream(filePath), {
      filename: path.basename(filePath),
      contentType: 'video/mp4',
    });

    const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendVideo`;
    const response = await axios.post(url, form, {
      headers: form.getHeaders(),
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
      timeout: 120000, // 2 daqiqa — katta fayllar uchun
    });

    if (response.data.ok) {
      console.log(`[TELEGRAM] Yuborildi ✅ | chat: ${chatId}`);
      // Yuborilgandan keyin faylni o'chirishingiz mumkin (ixtiyoriy):
      // fs.unlinkSync(filePath);
    } else {
      console.error('[TELEGRAM] Xato:', response.data);
    }
  } catch (err) {
    console.error('[TELEGRAM] Yuborishda xato:', err.message);
  }
}

module.exports = router;
