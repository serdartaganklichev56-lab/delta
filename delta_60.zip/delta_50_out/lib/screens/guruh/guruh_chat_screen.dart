import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../core/theme/app_colors.dart';
import '../../models/user_model.dart';
import '../../models/room_model.dart';

// Har foydalanuvchi uchun rang
Color _ismRangi(String uid) {
  final ranglar = [
    const Color(0xFF2196F3), // ko'k
    const Color(0xFF4CAF50), // yashil
    const Color(0xFFFF9800), // to'q sariq
    const Color(0xFFE91E63), // pushti
    const Color(0xFF9C27B0), // binafsha
    const Color(0xFF00BCD4), // moviy
    const Color(0xFFFF5722), // to'q qizil
    const Color(0xFF009688), // zangori yashil
  ];
  final index = uid.codeUnits.fold(0, (a, b) => a + b) % ranglar.length;
  return ranglar[index];
}

class GuruhChatScreen extends StatefulWidget {
  final RoomModel room;
  final UserModel user;
  const GuruhChatScreen({super.key, required this.room, required this.user});

  @override
  State<GuruhChatScreen> createState() => _GuruhChatScreenState();
}

class _GuruhChatScreenState extends State<GuruhChatScreen> {
  final _xabarCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final _focusNode = FocusNode();
  final Map<String, GlobalKey> _xabarKeylar = {};

  // Reply holati
  Map<String, dynamic>? _replyXabar;
  String? _replyDocId;

  // Tahrirlash holati
  String? _tahrirDocId;

  // Menga reply banner
  Map<String, dynamic>? _replyBanner;
  String? _replyBannerDocId;

  bool get _menDomla => widget.user.isDomla || widget.user.isCeo;

  // Oldingi xabarlar soni — yangi reply aniqlash uchun
  int _oldingiXabarSoni = 0;

  @override
  void dispose() {
    _xabarCtrl.dispose();
    _scrollCtrl.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  // Reply banner ni ko'rsatish
  void _replyBannerKorsat(Map<String, dynamic> data, String docId) {
    if (!mounted) return;
    setState(() {
      _replyBanner = data;
      _replyBannerDocId = docId;
    });
    // 4 soniyadan keyin yashirin
    Future.delayed(const Duration(seconds: 4), () {
      if (mounted && _replyBannerDocId == docId) {
        setState(() { _replyBanner = null; _replyBannerDocId = null; });
      }
    });
  }

  // O'sha xabarga scroll qilish
  void _xabarGaScroll(String docId) {
    final key = _xabarKeylar[docId];
    if (key?.currentContext != null) {
      Scrollable.ensureVisible(key!.currentContext!,
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeOut,
          alignment: 0.3);
    }
    setState(() { _replyBanner = null; _replyBannerDocId = null; });
  }

  CollectionReference get _chatRef => FirebaseFirestore.instance
      .collection('guruhlar')
      .doc(widget.room.id)
      .collection('chat');

  // ── Xabar yuborish / tahrirlash ──────────────────────────────────────────
  Future<void> _yuborish() async {
    final matn = _xabarCtrl.text.trim();
    if (matn.isEmpty) return;
    _xabarCtrl.clear();

    if (_tahrirDocId != null) {
      // Tahrirlash
      await _chatRef.doc(_tahrirDocId).update({
        'matn': matn,
        'tahrirlangan': true,
      });
      setState(() => _tahrirDocId = null);
    } else {
      // Yangi xabar
      final data = <String, dynamic>{
        'matn': matn,
        'uid': widget.user.uid,
        'ism': widget.user.fullName,
        'vaqt': FieldValue.serverTimestamp(),
      };
      // Reply
      if (_replyXabar != null) {
        data['replyIsmiga'] = _replyXabar!['ism'] ?? '';
        data['replyMatn'] = _replyXabar!['matn'] ?? '';
        data['replyDocId'] = _replyDocId ?? '';
      }
      await _chatRef.add(data);
      setState(() { _replyXabar = null; _replyDocId = null; });
    }

    _pastgaTush();
  }

  void _pastgaTush() {
    Future.delayed(const Duration(milliseconds: 200), () {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(_scrollCtrl.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      }
    });
  }

  // ── Uzoq bosish — amallar ─────────────────────────────────────────────────
  void _xabarAmallar(BuildContext ctx, String docId, Map<String, dynamic> data) {
    final menmi = data['uid'] == widget.user.uid;

    showModalBottomSheet(
      context: ctx,
      backgroundColor: const Color(0xFF1E1E2E),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 8),
          Container(width: 40, height: 4,
              decoration: BoxDecoration(color: Colors.white24,
                  borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 8),

          // Javob berish — hammada
          _amalTugma(Icons.reply, 'Javob berish', Colors.blue, () {
            Navigator.pop(ctx);
            setState(() {
              _replyXabar = data;
              _replyDocId = docId;
              _tahrirDocId = null;
            });
            _focusNode.requestFocus();
          }),

          // Nusxa olish
          _amalTugma(Icons.copy, 'Nusxa olish', Colors.grey, () {
            Navigator.pop(ctx);
            Clipboard.setData(ClipboardData(text: data['matn'] ?? ''));
            ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Nusxa olindi')));
          }),

          // Tahrirlash — faqat o'ziniki
          if (menmi)
            _amalTugma(Icons.edit_outlined, 'Tahrirlash', Colors.orange, () {
              Navigator.pop(ctx);
              setState(() {
                _tahrirDocId = docId;
                _replyXabar = null;
                _replyDocId = null;
              });
              _xabarCtrl.text = data['matn'] ?? '';
              _xabarCtrl.selection = TextSelection.fromPosition(
                  TextPosition(offset: _xabarCtrl.text.length));
              _focusNode.requestFocus();
            }),

          // O'chirish — o'ziniki yoki domla
          if (menmi || _menDomla)
            _amalTugma(Icons.delete_outline, 'O\'chirish', Colors.red, () async {
              Navigator.pop(ctx);
              await _chatRef.doc(docId).delete();
            }),

          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  Widget _amalTugma(IconData icon, String label, Color color, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: color, size: 22),
      title: Text(label, style: TextStyle(color: color, fontSize: 14)),
      onTap: onTap,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
        title: Text(widget.room.name,
            style: const TextStyle(color: AppColors.textPrimary,
                fontWeight: FontWeight.bold)),
      ),
      body: Column(children: [
        // Reply banner — menga javob berilganda
        if (_replyBanner != null)
          GestureDetector(
            onTap: () {
              // O'sha xabarga scroll
              final replyDocId = _replyBanner!['replyDocId'] as String?;
              if (replyDocId != null) _xabarGaScroll(replyDocId);
              // Yoki pastga tush — yangi xabarga
              _pastgaTush();
              setState(() { _replyBanner = null; _replyBannerDocId = null; });
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.fromLTRB(12, 6, 12, 0),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: AppColors.primaryDark.withValues(alpha: 0.85),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.primary.withValues(alpha: 0.4)),
                boxShadow: [
                  BoxShadow(color: Colors.black.withValues(alpha: 0.2),
                      blurRadius: 8, offset: const Offset(0, 2)),
                ],
              ),
              child: Row(children: [
                const Icon(Icons.reply, color: AppColors.primaryLight, size: 16),
                const SizedBox(width: 8),
                Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(_replyBanner!['ism'] ?? '',
                      style: const TextStyle(color: AppColors.primaryLight,
                          fontSize: 12, fontWeight: FontWeight.w600)),
                  Text(_replyBanner!['matn'] ?? '',
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: AppColors.primaryLight.withValues(alpha: 0.75),
                          fontSize: 12)),
                ])),
                const Icon(Icons.arrow_downward,
                    color: AppColors.primaryLight, size: 16),
              ]),
            ),
          ),

        // Xabarlar
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: _chatRef.orderBy('vaqt').snapshots(),
            builder: (context, snap) {
              if (!snap.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final xabarlar = snap.data!.docs;
              if (xabarlar.isEmpty) {
                return const Center(
                    child: Text("Hali xabar yo'q",
                        style: TextStyle(color: AppColors.textHint)));
              }
              // Yangi xabar reply tekshirish
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (xabarlar.length > _oldingiXabarSoni && _oldingiXabarSoni > 0) {
                  // Yangi kelgan xabarlarni tekshir
                  for (int i = _oldingiXabarSoni; i < xabarlar.length; i++) {
                    final d = xabarlar[i].data() as Map<String, dynamic>;
                    // Menga reply qilinganmi va o'zim yozmadimmi
                    if (d['replyDocId'] != null &&
                        d['uid'] != widget.user.uid &&
                        d['replyIsmiga'] == widget.user.fullName) {
                      _replyBannerKorsat(d, xabarlar[i].id);
                    }
                  }
                }
                _oldingiXabarSoni = xabarlar.length;
                _pastgaTush();
              });
              return ListView.builder(
                controller: _scrollCtrl,
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
                itemCount: xabarlar.length,
                itemBuilder: (context, i) {
                  final doc = xabarlar[i];
                  final d = doc.data() as Map<String, dynamic>;
                  final menmi = d['uid'] == widget.user.uid;
                  final rang = _ismRangi(d['uid'] ?? '');
                  final key = GlobalKey();
                  _xabarKeylar[doc.id] = key;
                  return _XabarWidget(
                    key: key,
                    docId: doc.id,
                    data: d,
                    menmi: menmi,
                    ismRangi: rang,
                    onLongPress: () => _xabarAmallar(context, doc.id, d),
                  );
                },
              );
            },
          ),
        ),

        // Reply preview
        if (_replyXabar != null)
          Container(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
            color: AppColors.surfaceLight,
            child: Row(children: [
              Container(width: 3, height: 36,
                  color: AppColors.primary,
                  margin: const EdgeInsets.only(right: 8)),
              Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_replyXabar!['ism'] ?? '',
                    style: const TextStyle(color: AppColors.primary,
                        fontSize: 12, fontWeight: FontWeight.w600)),
                Text(_replyXabar!['matn'] ?? '',
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: AppColors.textPrimary.withValues(alpha: 0.6),
                        fontSize: 12)),
              ])),
              IconButton(
                icon: const Icon(Icons.close, size: 18, color: AppColors.textHint),
                onPressed: () => setState(() {
                  _replyXabar = null;
                  _replyDocId = null;
                }),
              ),
            ]),
          ),

        // Tahrirlash preview
        if (_tahrirDocId != null)
          Container(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
            color: Colors.orange.withValues(alpha: 0.1),
            child: Row(children: [
              const Icon(Icons.edit, size: 16, color: Colors.orange),
              const SizedBox(width: 8),
              const Expanded(child: Text('Tahrirlash rejimi',
                  style: TextStyle(color: Colors.orange, fontSize: 12))),
              IconButton(
                icon: const Icon(Icons.close, size: 18, color: AppColors.textHint),
                onPressed: () => setState(() {
                  _tahrirDocId = null;
                  _xabarCtrl.clear();
                }),
              ),
            ]),
          ),

        // Input
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: const BoxDecoration(
              border: Border(top: BorderSide(color: AppColors.border))),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: _xabarCtrl,
                focusNode: _focusNode,
                style: const TextStyle(color: AppColors.textPrimary),
                decoration: InputDecoration(
                  hintText: _tahrirDocId != null
                      ? 'Tahrirlash...'
                      : 'Xabar yozing...',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(24),
                      borderSide: BorderSide.none),
                  filled: true,
                  fillColor: AppColors.surfaceLight,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 10),
                ),
                maxLines: null,
                onSubmitted: (_) => _yuborish(),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _yuborish,
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _tahrirDocId != null
                      ? Colors.orange
                      : AppColors.primaryDark,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  _tahrirDocId != null ? Icons.check : Icons.send,
                  color: AppColors.primaryLight, size: 18),
              ),
            ),
          ]),
        ),
      ]),
    );
  }
}

// ── Xabar widget ─────────────────────────────────────────────────────────────
class _XabarWidget extends StatelessWidget {
  final String docId;
  final Map<String, dynamic> data;
  final bool menmi;
  final Color ismRangi;
  final VoidCallback onLongPress;

  const _XabarWidget({
    super.key,
    required this.docId,
    required this.data,
    required this.menmi,
    required this.ismRangi,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final replyIsmiga = data['replyIsmiga'] as String?;
    final replyMatn = data['replyMatn'] as String?;
    final tahrirlangan = data['tahrirlangan'] as bool? ?? false;

    return Align(
      alignment: menmi ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: onLongPress,
        child: Container(
          margin: const EdgeInsets.only(bottom: 6),
          constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width * 0.75),
          child: Column(
            crossAxisAlignment: menmi
                ? CrossAxisAlignment.end
                : CrossAxisAlignment.start,
            children: [
              // Ism (boshqaniki uchun)
              if (!menmi)
                Padding(
                  padding: const EdgeInsets.only(left: 4, bottom: 2),
                  child: Text(data['ism'] ?? '',
                      style: TextStyle(fontSize: 11,
                          color: ismRangi,
                          fontWeight: FontWeight.w600)),
                ),

              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: menmi
                      ? AppColors.primaryDark
                      : AppColors.surfaceLight,
                  borderRadius: BorderRadius.only(
                    topLeft: const Radius.circular(16),
                    topRight: const Radius.circular(16),
                    bottomLeft: Radius.circular(menmi ? 16 : 4),
                    bottomRight: Radius.circular(menmi ? 4 : 16),
                  ),
                ),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  // Reply bloki
                  if (replyIsmiga != null && replyMatn != null) ...[
                    Container(
                      margin: const EdgeInsets.only(bottom: 6),
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(8),
                        border: Border(
                          left: BorderSide(
                            color: menmi
                                ? AppColors.primaryLight
                                : AppColors.primary,
                            width: 3,
                          ),
                        ),
                      ),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                        Text(replyIsmiga,
                            style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: menmi
                                    ? AppColors.primaryLight
                                    : AppColors.primary)),
                        Text(replyMatn,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontSize: 11,
                                color: menmi
                                    ? AppColors.primaryLight.withValues(alpha: 0.7)
                                    : AppColors.textPrimary.withValues(alpha: 0.6))),
                      ]),
                    ),
                  ],

                  // Xabar matni
                  Text(data['matn'] ?? '',
                      style: TextStyle(
                          color: menmi
                              ? AppColors.primaryLight
                              : AppColors.textPrimary,
                          fontSize: 14)),

                  // Vaqt + tahrirlangan
                  const SizedBox(height: 2),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    if (tahrirlangan) ...[
                      Text('tahrirlangan',
                          style: TextStyle(
                              fontSize: 9,
                              color: menmi
                                  ? AppColors.primaryLight.withValues(alpha: 0.5)
                                  : AppColors.textHint,
                              fontStyle: FontStyle.italic)),
                      const SizedBox(width: 4),
                    ],
                    Text(_vaqt(data['vaqt']),
                        style: TextStyle(
                            fontSize: 10,
                            color: menmi
                                ? AppColors.primaryLight.withValues(alpha: 0.5)
                                : AppColors.textHint)),
                  ]),
                ]),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _vaqt(dynamic vaqt) {
    if (vaqt == null) return '';
    try {
      final dt = (vaqt as dynamic).toDate() as DateTime;
      final h = dt.hour.toString().padLeft(2, '0');
      final m = dt.minute.toString().padLeft(2, '0');
      return '$h:$m';
    } catch (_) {
      return '';
    }
  }
}
